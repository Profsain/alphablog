![](https://img.shields.io/badge/Microverse-blueviolet)

<!-- TABLE OF CONTENTS -->

# 📗 Table of Contents

- [📖 About the Project](#about-project)
  - [🛠 Built With](#built-with)
    - [Tech Stack](#tech-stack)
    - [Key Features](#key-features)
  - [🚀 Live Demo](#live-demo)
- [💻 Getting Started](#getting-started)
  - [Setup](#setup)
  - [Prerequisites](#prerequisites)
  - [Install](#install)
  - [Usage](#usage)
  - [Run tests](#run-tests)
  - [Deployment](#triangular_flag_on_post-deployment)
- [👥 Authors](#authors)
- [🔭 Future Features](#future-features)
- [🤝 Contributing](#contributing)
- [⭐️ Show your support](#support)
- [🙏 Acknowledgements](#acknowledgements)
- [❓ FAQ](#faq)
- [📝 License](#license)

<!-- PROJECT DESCRIPTION -->

# 📖 [Ruby on Rails Blog Web App] <a name="about-project"></a>

A Ruby on Rails application for creating new blog post, viewing posts, edit post, delete posts and styled with Bootstrap.

## 🛠 Built With <a name="built-with"></a>

### Tech Stack <a name="tech-stack"></a>

<details>
  <summary>Client</summary>
  <ul>
    <li><a href="https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/HTML_basics">HTML</a></li>
    <li><a href="https://getbootstrap.com/">Bootstrap</a></li>
    <li><a href="https://rubyonrails.org/">ERB</a></li>
  </ul>
</details>

<details>
  <summary>Server</summary>
  <ul>
    <li><a href="https://rubyonrails.org/">Ruby on Rails</a></li>
  </ul>
</details>

<details>
<summary>Database</summary>
  <ul>
    <li><a href="https://www.postgresql.org/">PostgreSQL</a></li>
  </ul>
</details>

<!-- Features -->

### Key Features <a name="key-features"></a>

- **Registration and Login**
- **Transaction lists**
- **Add new transaction**
- **View single transaction details**

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- LIVE DEMO -->

## 🚀 Live Demo <a name="live-demo"></a>

- [Live Demo Link](https://alpha-blog-app.herokuapp.com/)

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- GETTING STARTED -->

## 💻 Getting Started <a name="getting-started"></a>

To get a local copy up and running, follow these steps.

### Prerequisites

>## Getting Started
To get a local copy up and running follow these simple example steps.

### Prerequisites
- Have a computer and internet connection
- Have `Ruby` installed on your computer
- Have a basic knowledge of `Ruby` and `OOP` concept
- Have a general understanding of what testing is
- Have `visual-studio code` or any other code editor installed on your computer.

### Setup
- In order to get a copy of this project you need to clone the repo
  git clone https://github.com/Profsain/alphablog.git
- cd spendtrac
### Install
- Run the command bellow in your terminal to get all required files
```
bundle install
```

### Run Server
- Run the command bellow in your terminal
  rails server

### Run tests
you can run one of the following command in your terminal
1. Run testing
```Ruby
rspec spec
```
2. Run linters
```Ruby
> Rubocop --color
> Rubocop -A
> npx stylelint "**/*.{css,scss}"
```
## Author

👤 **Husseini Mudi Profsain**

- GitHub: [@githubhandle](https://github.com/Profsain)
- Twitter: [@twitterhandle](https://twitter.com/profsain)
- LinkedIn: [LinkedIn](https://www.linkedin.com/in/profsain)

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!

Feel free to check the [issues page](https://github.com/Profsain/alphablog/issues/).

## Show your support

Give a ⭐️ if you like this project!

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- ACKNOWLEDGEMENTS -->

## 🙏 Acknowledgments <a name="acknowledgements"></a>

I would like to thank Microverse team and Micronauts for their support

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## 📝 License

This project is [MIT]() licensed.
